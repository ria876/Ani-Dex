using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraRollManager : MonoBehaviour
{

    public NativeFilePicker.Permission permission; // Permission to access Camera Roll

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
