using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainMenuScreenScript : MyScreen
{
    public Button scanScreenButton;
    public Button searchScreenButton;
    public Button previousScansButton;
    public Button closeAppButton; 

    // Start is called before the first frame update
    void Start()
    {
        
    }
}
